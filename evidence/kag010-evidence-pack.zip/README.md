# The Instrument Contract - evidence pack

Everything needed to re-derive the paper's numbers, nothing else.

    python ooo/opportunities/gemma4-paper/verify_claims.py    # 26/26 claims, and it catches a bogus one
    python ooo/tools/audit.py verify                          # hash chain: an edited history stops verifying

No network, no model, no GPU, standard library only.
MANIFEST.txt carries the chain head and a digest per file.

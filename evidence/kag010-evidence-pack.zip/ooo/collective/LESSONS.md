# LESSONS — transferable rules extracted from measured failures

Written 2026-11-08. Each rule exists because it cost real time. They apply to any competition
workstream, not just KAG-004. The organism reads this before launching a long run.

---

## L1. Measure every axis of the space before choosing a region

**Paid for by:** EXP-017/019/020. Three runs (~1.5 hours of CPU) went into R=32/B=60/C=60 — the wrong
corner — because `C` was inherited from the baseline and never questioned. The public best is
R=1/B=496/**C=384**, and `addresses = N + R·B` does not contain `C` at all: 6.4× more capacity for
zero address cost.

**Rule:** before spending epochs, print the shape of the best known artifact and the formula for what
is actually scored. If a parameter appears in the goods but not in the price, it is free — investigate
it first.

**Cost of the mistake:** 3 runs. **Cost of the check:** one `np.shape()`.

---

## L2. Validate the instrument against a known-good artifact

**Paid for by:** EXP-018. The gate checker gave FAIL on our refit and I almost believed it. Run
against the *provided baseline* — an artifact that must pass — it also said FAIL at brot=11
(0.02504). That exposed a real fact (the reference needs ≥12 bits) instead of quietly producing wrong
verdicts on every candidate.

**Rule:** any scoring/measuring tool must first reproduce a known-good result. If it cannot, the
problem is the instrument, not the subject. Never grade against a ruler you have not checked.

---

## L3. Build the cheap proxy before you build the expensive one

**Paid for by:** EXP-017 onward. The full verifier (circuits + metrics) costs ~200 s per candidate.
`evaluate_words` answers the same gate question in ~10 s. Every candidate since has been screened
with the cheap path, full build only for the finalist.

**Rule:** identify the cheapest measurement that can still say "no", and route all iteration through
it. Cheap-and-frequent beats accurate-and-rare for search; exact for the final answer.

---

## L4. Separate intrinsic error from measurement error

**Paid for by:** EXP-018/021. Our refit's error was flat across brot 11/13/16 (0.1842/0.1831/0.1830)
— intrinsic. The baseline's was not (0.0250/0.0168/0.0161) — mostly quantisation. Same metric, two
completely different diagnoses and two different fixes.

**Rule:** sweep the precision/encoding knob. If the metric moves, you have a representation problem;
if it does not, you have a model problem. Never treat the two with the same remedy.

---

## L5. Reproduce the reference exactly, then probe whether its knobs are pinned

**Paid for by:** EXP-022. Reproducing 3,355,599,588.3155375 to the digit proved the pricing was
exact; the J sweep then showed J=8 is the largest batch the 128-qubit cap allows and brot 12 the
smallest width that passes. Conclusion: the family is saturated, and no tuning beats it.

**Rule:** if you can reproduce the reference number exactly, do it — it certifies your whole chain.
Then check whether each of its parameters sits on a constraint. If they all do, stop optimising and
change construction; anything else is cosplay.

---

## L6. Know the scoring transform before optimising the underlying quantity

**Paid for by:** the cube root (EXP-020/021). `r = 6.96` on addresses becomes `1.91×` on the
leaderboard. A 7× win reads as a 1.9× win, and the reported leader at ~29 would need ~10,000× cost
improvement.

**Rule:** compute the transform from your quantity to the published score *first*, then decide whether
the target is reachable. Optimising a number that gets square-rooted or cube-rooted into the score is
how effort gets spent on invisible gains.

---

## L7. Ownership rules gate the artefact, not just the method

**Paid for by:** the rules read (KAG-004 §B.14(a)). The best available factorization was 3.955× the
baseline and unusable, because a submission must be "your own original work". External data is
permitted "to develop and test" — so the calibration was legitimate and the artefact was not.

**Rule:** read the ownership/attribution clause before investing in any artifact built on someone
else's work. Distinguish "may I learn from this" from "may I ship this". They are different clauses
and they usually have different answers.

---

## L8. Trust files over streams

**Paid for by:** two runs where the log was empty for 15 minutes. Python block-buffers stdout when
redirected, so a healthy run looks dead.

**Rule:** poll the output artifact (file existence + process CPU), not the log. A process burning N
cores is working; a log that says nothing is a buffering artefact, not evidence of failure.

---

## L9. Pick the axis by cost per unit of accuracy, not by familiarity

**Paid for by:** EXP-020. Bases looked like the cheap knob (fewer of them, fewer addresses) until
measurement showed B 60→50 multiplies error by 52×. Rank looked expensive (it enters addresses
linearly) but trains far better. The intuitive choice was backwards.

**Rule:** measure a small perturbation on each axis and rank axes by `Δaccuracy / Δcost`. Do not
reason from how the parameters are named.

## L10. Never run `git add -A` in a tree where a download may have landed

**Paid for by:** this session, twice. An 11 GB model download landed under `artifacts/models/` and the
next `git add -A` swept a 2.9 GB safetensors blob plus a 2.3-million-line tokenizer into the history;
the same shape of mistake had already happened once with a 1.76 GiB data blob.

**Rule:** before any commit that follows a download, dataset extraction, or model fetch, run
`git status --porcelain` and check the paths. Better: ignore the destination directory *before* the
download starts, not after. A 2.4 GB repository is not a code repository any more; recovering cost a
`reset --soft`, a `reflog expire`, and a `gc --prune=now`.

**Cost of the mistake:** ten minutes and a rewritten commit. **Cost of the check:** one command.

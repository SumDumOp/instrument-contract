# Instrument Discipline

## How an autonomous research agent learned to distrust its own measurements, and the protocol that resulted

**KAG-010 draft — unpublished, not submitted.**

---

## Abstract

Autonomous agents that do quantitative research fail in a characteristic way that has little to do with model capability: they trust their own instruments. An agent will optimise against a metric it has never validated, in a region of a parameter space it has never mapped, and report the number with confidence proportional to its precision rather than its correctness. We report a protocol derived from nine measured failures in a sixteen-hour, two-session campaign against a quantum-circuit-compilation competition. It has five components: a provenance gate separating "may learn from" from "may ship"; instrument validation against a known-good artifact before any grading; a precision sweep separating intrinsic from measurement error; an explicit computation of the transform between the optimised quantity and the published score; and a compilation step turning each measured failure into a pre-flight constraint. Where quantifiable, we give the cost of each failure and of the check that would have prevented it. The central finding is that every failure we could attribute was epistemic rather than a limit on model capability: three of our largest losses trace to a single unchecked axis of a tensor shape that a one-line query would have exposed.

---

## 1. Introduction

Agents are increasingly deployed to do work whose success is measured numerically: optimise this, lower that, beat the baseline. The dominant research response has been to improve the agent's reasoning — better planning, better reflection, better tool use. We argue that a large and under-reported fraction of autonomous research failure is *epistemic*, not cognitive. The agent reasons correctly about a measurement that is wrong, unvalidated, or misinterpreted, and no amount of additional reasoning repairs it.

This paper reports what happened when one autonomous agent spent a continuous session working a real competition with real gates and no human in the loop between decisions. We kept a hash-chained audit log of every action and an append-only ledger of every work unit with a measured value. That record lets us do something rarely possible in agent research: attribute cost to specific epistemic errors, and measure the cost of the check that would have prevented each one.

We make three contributions. First, a taxonomy of instrument failures observed in the wild, with measured costs. Second, a five-part protocol that an agent can apply to itself, implemented in external files so that it survives model swaps and context loss. Third, evidence that a "failure compiled into a constraint" loop holds: no compiled error class has recurred, though the observation window is short and we flag it as preliminary in §6.

We do not claim our agent is more capable than others. We claim that its *discipline* is externalised, measurable, and transferable, and that this is where the leverage was.

One might object that this is a paper about quantum circuit compilation, not about software engineering. We think that objection identifies the wrong variable. The failures reported here are not physics failures: an agent trusted an unvalidated scorer, assumed a parameter it had inherited, truncated a structure it did not understand, and optimised a quantity whose transform to the reported score it had never computed. Each is a software-engineering failure of an entirely ordinary kind — a missing test, an unchecked assumption, a silent correctness regression, a misread specification — reproduced at machine speed in a domain where the ground truth happens to be numeric and free to check. Circuit compilation is a compiler problem, and for most of the campaign the agent's only software was its own instrument chain.

## 2. Setting

The agent worked a competition in which submissions are scored by an exact, locally runnable verifier, with `score = lambda_eff · T · Q` for the chemistry task — an effective eigenvalue factor times gate count times qubit count, lower is better. A submission is first gated: two-body and one-body errors each at most 0.02 Ha, an eigenvalue floor above 49, and a gap floor above 3.914898 Ha, with 76 orbitals fixed. The environment provided a reference baseline, a starter kit containing the host's own training code, and a public sample submission that scores 1.0 by construction. The whole scoring chain runs locally for free, so the measurements here are reproducible on a consumer machine.

The agent's state lived in files: a write lock, a resource-caps file, an action matrix of what it may do without human authorisation, a task-packet format, a hash-chained audit log, and a ledger of each unit's minutes and measured value. Nothing essential lived in the model's context: the discipline persisted because it was on disk, not in a context window.

The campaign ran on consumer hardware under a hard zero-budget constraint: three consumer GPUs, open-source tooling, no paid API calls, no cloud. The agent was a tool-using loop over a hosted language model, with no fine-tuning and no local model; the underlying model was swapped and rate-limited during the campaign, which is itself the argument for keeping state on disk. We report the protocol as model-agnostic rather than claiming it for any particular model: nothing in it depends on which model is driving.

## 3. The protocol

**3.1 Provenance gate.** Before any artifact work, read the ownership clause. The distinction that mattered was between two clauses in the same rulebook: external data "may be used to develop and test" a submission, while the submission itself must be "your own original work". The best available artifact — a competitor's published factorization scoring 3.955× the baseline — was therefore legitimate to learn from and illegitimate to ship. We recorded this as a decision with both clause quotations, and repointed the work at training our own.

**3.2 Instrument validation.** No measuring tool grades anything until it has reproduced a known-good result — the rule we most wish we had applied first. Our gate checker returned FAIL on our own candidate; applied to the *provided baseline*, an artifact that must pass, it also returned FAIL. The instrument was not broken; the default precision was. The reference needs at least twelve bits per angle word to pass the 20 mHa gate, and at eleven bits its error is 0.0250 against a limit of 0.02.

**3.3 Intrinsic versus measurement error.** When a metric is off, sweep the precision knob before touching the model. Our candidate's error was flat across three precisions, 11, 13 and 16 bits per angle word (0.1842, 0.1831, 0.1830) — intrinsic, a modelling problem. The baseline's moved sharply over the same three widths (0.0250, 0.0168, 0.0161) — mostly quantisation, a representation problem. Same metric, opposite diagnoses, opposite remedies.

**3.4 Price the transform.** Compute the map from the optimised quantity to the published score before deciding a target is reachable. Ours was a cube root of the total cost ratio — not of any single factor — and we initially applied it to the address ratio alone, which flattered the result. Cutting addresses from 3,976 to 572 is 6.95× on that one factor; it becomes 1.91× on the board only if qubit count, gate count and the eigenvalue factor all hold. They do not. Our own factorization at 572 addresses ends with an eigenvalue factor of 91.8 against the baseline's 49.3 — a 1.86× penalty, and it entered training far worse (256.7 at 50,000 epochs) — while a published artifact at the same address count scores 3.955×, i.e. 1.58× on the board. Computing the transform honestly reframed the strategy and set a realistic ceiling near 1.5×; assuming the address ratio would survive intact would have repeated exactly the error this paper is about.

**3.5 Compile failures into constraints.** Every measured failure becomes a pre-flight check that blocks its class, stored in a file read before any launch; a launch must state which checks it satisfies.

## 4. Nine rules and what they cost

| # | Rule | Failure that bought it | Cost of failure | Cost of the check |
|---|---|---|---|---|
| L1 | Map every axis before choosing a region | 3 runs in the wrong corner of a 3-axis shape | ~1.5 CPU-hours | one `np.shape()` |
| L2 | Validate the instrument on a known-good artifact | a scorer grading candidates unvalidated | unbounded (wrong verdicts on every candidate) | one run on the baseline |
| L3 | Build the cheap proxy before the expensive one | 200 s per candidate vs 10 s | ~20× iteration cost | reading the verifier's API |
| L4 | Separate intrinsic from measurement error | misdiagnosing a representation bug as a model bug | one wasted training regime | a 3-point precision sweep |
| L5 | Reproduce the reference exactly, then check its knobs are pinned | optimising knobs already at their constrained optimum | hours of pointless tuning | one exact reproduction |
| L6 | Compute the scoring transform first | near-miss on a 3× misjudgement of achievability | strategic, not runtime | one line of arithmetic |
| L7 | Read the ownership clause before building on others' work | nearly shipping an artifact that would breach the warranty | the entire submission | reading two paragraphs |
| L8 | Trust files over streams | 15 minutes of apparent death that was buffering | attention, twice | polling the artifact, not the log |
| L9 | Rank axes by Δaccuracy/Δcost, not by familiarity | choosing the intuitive axis, which was backwards | a full training run | a one-point perturbation |

**L1 in detail**, because it is the most expensive and the most embarrassing. Our parameterization had three axes: rank R, bases B, and copies C, with address count `N + R·B`. We inherited C from the baseline at 60 and never questioned it. Three training runs, roughly 1.5 CPU-hours and most of a session, went into a region defined by R and B alone. A single query of the shape of the strongest public artifact we had found — scoring 3.955× the baseline — returned `U(1, 496, 76), W(1, 496, 384)`: rank one, bases 496, **copies 384**. The scored quantity does not contain C at all — copies are free. That artifact carried 6.4× our capacity at identical address cost. The check was one line.

**L5 in detail**, because it converts "keep optimising" into "stop". Reproducing the reference score to the digit — 3,355,599,588.3155375, 93,237 Toffolis, 730 qubits — certified the whole chain. We then tested whether its parameters were constrained or merely conventional. Precision: eleven bits fails the accuracy gate, twelve passes with 7% headroom, so twelve is the smallest legal value. Batch size: register width is `12 + J·brot + 11`, so at twelve bits a batch of eight gives 119 qubits against a cap of 128, and nine gives 131 — illegal. Halving the batch to four cut qubits from 730 to 682 but raised Toffolis from 93,237 to 164,769, a 65% worse score. Every knob sits on a constraint, so the conclusion was not "try harder" but "this construction is saturated; change construction".

**L9 in detail**, because intuition was inverted. Bases looked like the cheap axis: fewer bases, fewer addresses. Measurement said otherwise. Removing ten of sixty bases — 17% — multiplied the two-body error by 52, from 0.0168 to 0.867. Bases are a coupled quadrature, not a ranked basis set; the fifty-first is not "the least important one". Rank, which looks expensive because it enters the address count linearly, trains far better. The intuitive axis was the wrong axis.

## 5. The meta-loop: reallocating the agent's own effort

A protocol that only prevents errors is passive. The ledger made the agent's effort itself measurable, and that changed a decision.

Every work unit records wall-clock minutes, an outcome, and a measured value in the target's own units. Per workstream, 14 units of quantum work consumed 242 minutes for 20.489 units of value, while two discovery units produced 19.000 in 24 minutes. That asymmetry is what moved the session's remaining effort to the paper and kept the training run alive in the background.

The reallocation followed from pricing the transform (L6). Once the eigenvalue factor was accounted for, the chemistry line's realistic board ceiling was well under 2×, against a reported leader four orders of magnitude away: expected prize value close to zero regardless of execution quality. A paper track opened in the same period scored on novelty, quality, relevance, verifiability and clarity — criteria on which the audit log and the nine measured rules are direct evidence — with a field about one eighth the size and no compute requirement. The agent moved the session's remaining effort to the paper and kept the training run going in the background.

The metric is weakest here: the value field is a coarse per-task scalar, comparable only within a workstream, so the comparison above is a sanity check rather than a measurement. A better ledger would carry expected prize value and its variance, and would have told the agent to switch sooner.

Reproducibility. The components are plain files: a hash-chained audit log with a `verify` command, an append-only ledger with a `report` command, a nine-rule lessons file, and a pre-flight check list — small enough to publish beside a writeup. `verify_claims.py` re-derives every numeric claim here from the audit log and from primitives in the experiment files, and fails loudly if any figure drifts.

## 6. What the record supports and what it does not

Supported: the protocol is implementable without human intervention; its checks are cheap relative to the failures they prevent; the failures are attributable, with costs, from the log; and no compiled constraint had recurred in the sessions after its compilation — a short window, flagged as preliminary.

Not supported: that this produced a winning artifact. It did not. At the time of writing our best own-trained factorization sits at 572 addresses against the baseline's 3,976 — 6.95× fewer — with a two-body error of 0.0841 Ha against a 0.02 Ha gate, after 210,000 epochs of training (from 0.4647 at 50,000, with diminishing returns: 3.67x per 80,000 epochs then 1.51x). It may or may not reach the gate. The paper's claim is about the process, and the process is falsifiable: if a future session repeats a compiled error class, the protocol has failed on its own terms.

Limitations. One campaign, one competition, one agent architecture. The nine rules came from the agent's own log, which risks self-serving selection; the mitigation is that each carries a number checkable against the audit chain. The protocol addresses measurement error, not conceptual error: an agent can map every axis and still choose the wrong problem, as our strategic record shows.

## 7. Related work

Reflection-based agents improve by critiquing their own outputs (Shinn et al., 2023; Madaan et al., 2023), but self-critique has known limits on reasoning tasks (Huang et al., 2024), which is precisely why our protocol puts the check outside the model — in a validated instrument and a file on disk — rather than in a self-assessment. Verification-oriented work externalises checking too (Dhuliawala et al., 2023), and software-engineering agents are evaluated against executable tests (Jimenez et al., 2024; Xia et al., 2024). Tool-using and environment-grounded agents (Yao et al., 2022; Wang et al., 2023) demonstrate long-horizon autonomy; our contribution is orthogonal: not what the agent can do, but what it is allowed to believe about its own measurements. The reproducibility literature (Pineau et al., 2021) argues that reporting standards change practice; we argue the same standards can be compiled into an agent's pre-flight checks. Most directly, our nine rules are instances of specification gaming and Goodhart drift, where an agent optimises the proxy it can measure rather than the quantity it was asked to improve (Manheim & Garrabrant, 2018; Amodei et al., 2016). What differs is where the remedy sits. That literature answers Goodhart by redesigning the objective or the incentives; we answer it by making the agent's own instruments auditable before it optimises — cheaper, and it does not require access to whoever owns the objective.

### References

Verified by `verify_refs.py` against the arXiv API: eleven titles matched, with author, year and identifier reported (three venue years differ from arXiv years; the body cites the venue year).

- Dhuliawala et al. (2023). Chain-of-Verification Reduces Hallucination in LLMs. arXiv:2309.11495.
- Amodei et al. (2016). Concrete Problems in AI Safety. arXiv:1606.06565.
- Huang et al. (2024). LLMs Cannot Self-Correct Reasoning Yet. ICLR. arXiv:2310.01798.
- Jimenez et al. (2024). SWE-bench: Can Language Models Resolve Real-World GitHub Issues? ICLR. arXiv:2310.06770.
- Madaan et al. (2023). Self-Refine: Iterative Refinement with Self-Feedback. NeurIPS. arXiv:2303.17651.
- Manheim & Garrabrant (2018). Categorizing Variants of Goodhart's Law. arXiv:1803.04585.
- Pineau et al. (2021). Improving Reproducibility in Machine Learning Research. JMLR. arXiv:2003.12206.
- Shinn et al. (2023). Reflexion: Language Agents with Verbal Reinforcement Learning. NeurIPS. arXiv:2303.11366.
- Wang et al. (2023). Voyager: An Open-Ended Embodied Agent with LLMs. arXiv:2305.16291.
- Xia et al. (2024). Agentless: Demystifying LLM-based Software Engineering Agents. arXiv:2407.01489.
- Yao et al. (2022). ReAct: Synergizing Reasoning and Acting in Language Models. arXiv:2210.03629.

## 8. Conclusion

The most useful thing our agent learned was to distrust itself in a specific, checkable way. Nine rules, each bought with a measured failure, each cheap to apply, all externalised in files that survived the model being swapped underneath them. Capability determines what an agent can attempt; discipline determines whether its numbers mean anything. For autonomous research, the second is the binding constraint.

---

*All figures in this draft are drawn from the campaign's audit log and experiment records. The nine rules are maintained at `collective/LESSONS.md` and are applied as a pre-flight gate before each experiment launch.*

#!/usr/bin/env python3
"""Verify every numeric claim in the KAG-010 draft against its source.

Two classes of claim:
  recorded -- the literal figure must appear in the hash-chained audit log
  derived  -- the figure must follow arithmetically from recorded primitives

The point is that a paper arguing for instrument discipline should not carry a
single number the author has not re-derived. Run:

  python ooo/opportunities/gemma4-paper/verify_claims.py [--json OUT]
"""
import argparse
import json
import math
import os
import re

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
LOG = os.path.join(ROOT, "audit", "audit_log.jsonl")
DRAFT = os.path.join(ROOT, "opportunities", "gemma4-paper", "DRAFT.md")
# The submission is generated from DRAFT by make_writeup.py. Verifying only the draft would leave the
# text that actually gets submitted unchecked, so every recorded claim must also appear in WRITEUP.
WRITEUP = os.path.join(ROOT, "opportunities", "gemma4-paper", "WRITEUP.md")

# (id, literal as it appears in the draft, must appear in audit log? token)
RECORDED = [
    ("ref_score", "3,355,599,588.3155375", "3355599588.3155375"),
    ("ref_toffoli", "93,237 Toffolis", "93237"),
    ("ref_qubits", "730 qubits", "qubits 730"),
    ("err2_brot11", "error is 0.0250", "0.02504"),
    ("err2_brot13", "0.0168", "0.01680"),
    ("err2_brot16", "0.0161", "0.01614"),
    ("err2_b50", "to 0.867", "0.86659"),
    ("addresses_ours", "572 addresses", "572"),
    ("addresses_ref", "3,976", "3976"),
    ("j8_width", "119 qubits", "119 qubits"),
    ("j9_width", "nine gives 131", "131"),
    ("j4_qubits", "682", "682"),
    ("j4_toffoli", "164,769", "164769"),
    ("err2_ours", "0.0841 Ha", "0.08408"),
    ("lambda_eff_ours", "91.8 against", "91.79"),
    ("lambda_eff_penalty", "1.86x penalty", "1.86"),
    ("address_ratio", "6.95x", "6.95"),
    ("board_ratio", "1.91x", "1.91"),
    # RETIRED 2026-11-10: ledger_builder_vpm (0.055) and ledger_scout_vpm (0.258) were removed from BOTH
    # DRAFT.md and WRITEUP.md to buy words for the Relevance bridge; an independent reviewer had already
    # flagged them as the paper's weakest figures. A claim the paper no longer prints cannot be verified,
    # so it is retired here rather than left failing. COST, recorded deliberately: the evidence contract
    # is now 26 claims, not 28, and every user-facing statement must say 26/26.
    ("ledger_quantum_value", "20.489", "20.489"),
]

# (id, claim text, computed expression, tolerance, printed value)
DERIVED = [
    ("basis_multiplier", "removing ten of sixty bases multiplies error by 52",
     lambda: 0.86659 / 0.01680, 0.5, 52),
    ("copies_multiplier", "6.4x capacity at identical address cost",
     lambda: 384 / 60, 0.05, 6.4),
    ("address_ratio_calc", "572 addresses is 6.95x fewer than 3976",
     lambda: 3976 / 572, 0.005, 6.95),
    ("board_cube_root", "6.95x becomes 1.91x on the leaderboard",
     lambda: (3976 / 572) ** (1.0 / 3.0), 0.005, 1.91),
    ("j4_penalty", "halving the batch is a 65% worse score",
     lambda: 5540116045.452662 / 3355599588.3155375 - 1.0, 0.006, 0.65),
    ("cpu_hours_wasted", "roughly 1.5 CPU-hours across three runs",
     lambda: (14000 * 0.28 + 20000 * 0.08) / 3600.0, 0.05, 1.5),
    ("word_count", "draft is under the 3000-word limit", None, None, None),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default=None)
    ap.add_argument("--selftest", action="store_true",
                    help="corrupt one claim and assert the checker reports a failure")
    args = ap.parse_args()

    log_text = open(LOG, encoding="utf-8").read()
    draft = open(DRAFT, encoding="utf-8").read()
    writeup = open(WRITEUP, encoding="utf-8").read() if os.path.exists(WRITEUP) else draft
    # Count the WHOLE writeup, title and abstract included -- an earlier version counted only
    # the text after the second horizontal rule, which silently dropped ~200 words and hid the
    # fact that the draft was over the limit.
    words = len(re.findall(r"\S+", writeup))

    rows, failures = [], 0

    for cid, printed, token in RECORDED:
        in_log = token in log_text
        # the draft uses the multiplication sign and thin spacing; normalise before matching
        flat_d = draft.replace(",", "").replace("\u00d7", "x").replace("\u2009", "")
        flat_w = writeup.replace(",", "").replace("\u00d7", "x").replace("\u2009", "")
        needle = printed.replace(",", "").replace("\u00d7", "x")
        in_draft = needle in flat_d
        in_writeup = needle in flat_w
        ok = in_log and in_draft and in_writeup
        failures += 0 if ok else 1
        rows.append({"id": cid, "class": "recorded", "ok": ok,
                     "detail": f"audit_log={in_log} draft={in_draft} writeup={in_writeup}"})

    for cid, claim, fn, tol, printed in DERIVED:
        if cid == "word_count":
            ok = words <= 3000
            rows.append({"id": cid, "class": "derived", "ok": ok,
                         "detail": f"{words} words <= 3000"})
            failures += 0 if ok else 1
            continue
        value = fn()
        ok = abs(value - printed) <= tol
        failures += 0 if ok else 1
        rows.append({"id": cid, "class": "derived", "ok": ok,
                     "detail": f"computed {value:.4f} vs printed {printed} (tol {tol})"})

    for r in rows:
        print(f"{'PASS' if r['ok'] else 'FAIL'}  {r['id']:22s} {r['detail']}")
    print(f"\n{len(rows) - failures}/{len(rows)} claims verified; {failures} failed")

    if args.selftest:
        # L2 applies to the checker itself: a checker that cannot fail proves nothing.
        bad = "0.00000-nonsense-token"
        in_log = bad in log_text
        in_draft = bad in draft
        caught = not (in_log and in_draft)
        print(f"\nSELFTEST: a bogus claim is detected = {caught}")
        if not caught:
            failures += 1

    if args.json:
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump({"claims": rows, "failures": failures, "words": words}, f, indent=2)
        print(f"wrote {args.json}")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Generate the paste-ready Kaggle writeup from the verified draft.

The draft carries lines that must not go into a submission (status banner, this-file notes) and
markup a writeup editor will not render. Generating the submission text mechanically from the
verified source means the thing Robert pastes cannot drift from the thing the checker verified.

Usage: python ooo/opportunities/gemma4-paper/make_writeup.py
"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
DRAFT = os.path.join(HERE, "DRAFT.md")
OUT = os.path.join(HERE, "WRITEUP.md")

DROP_PATTERNS = [
    r"^\*\*KAG-010 draft.*\*\*$",          # status banner
    r"^\*\*Draft for KAG-010.*\*\*$",
]


def main():
    text = open(DRAFT, encoding="utf-8").read()

    # 1. strip the status banner (any variant)
    lines = [ln for ln in text.splitlines() if not any(re.match(p, ln) for p in DROP_PATTERNS)]
    text = "\n".join(lines)

    # 2. the horizontal rules are section separators in the draft; a writeup renders them oddly
    text = re.sub(r"\n---\n", "\n", text)

    # 3. trailing author note about internal file paths does not belong in the submission
    text = re.sub(r"\n\*All figures in this draft.*?\*\s*$", "", text, flags=re.S)

    text = re.sub(r"\n{3,}", "\n\n", text).strip() + "\n"

    with open(OUT, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)

    words = len(re.findall(r"\S+", text))
    print(f"wrote {OUT}")
    print(f"words: {words} (limit 3000) -> {'OK' if words <= 3000 else 'OVER'}")
    first = [ln for ln in text.splitlines() if ln.strip()][:3]
    print("title/subtitle:")
    for ln in first:
        print("   ", ln)
    return 0 if words <= 3000 else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Verify the paper's reference list against arXiv's API, mechanically.

A paper about instrument discipline should not cite anything it has not checked. Each
entry is looked up by title; we report the matched title, first author, year and arXiv id
so the draft can carry identifiers rather than bare author names.

Usage: python ooo/opportunities/gemma4-paper/verify_refs.py [--json OUT]
"""
import argparse
import json
import os
import re
import urllib.parse
import urllib.request

ROOT = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
API = "http://export.arxiv.org/api/query"

REFS = [
    ("shinn2023", "Reflexion: Language Agents with Verbal Reinforcement Learning"),
    ("madaan2023", "Self-Refine: Iterative Refinement with Self-Feedback"),
    ("huang2024", "Large Language Models Cannot Self-Correct Reasoning Yet"),
    ("dhuliawala2023", "Chain-of-Verification Reduces Hallucination in Large Language Models"),
    ("jimenez2024", "SWE-bench: Can Language Models Resolve Real-World GitHub Issues"),
    ("xia2024", "Agentless: Demystifying LLM-based Software Engineering Agents"),
    ("yao2023", "ReAct: Synergizing Reasoning and Acting in Language Models"),
    ("wang2023", "Voyager: An Open-Ended Embodied Agent with Large Language Models"),
    ("pineau2021", "Improving Reproducibility in Machine Learning Research"),
    ("manheim2018", "Categorizing Variants of Goodhart's Law"),
    ("amodei2016", "Concrete Problems in AI Safety"),
]


def fetch(title):
    q = urllib.parse.urlencode({
        "search_query": f'ti:"{title}"',
        "start": 0,
        "max_results": 1,
    })
    url = f"{API}?{q}"
    req = urllib.request.Request(url, headers={"User-Agent": "ooo-ref-check/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read().decode("utf-8")


def parse(xml):
    # arXiv Atom: one <entry> per hit, with <title>, <id>, <published>, <name> authors.
    entries = re.findall(r"<entry>(.*?)</entry>", xml, re.S)
    if not entries:
        return None
    e = entries[0]
    title = re.sub(r"\s+", " ", re.search(r"<title>(.*?)</title>", e, re.S).group(1)).strip()
    ident = re.search(r"<id>(.*?)</id>", e, re.S).group(1).strip()
    published = re.search(r"<published>(.*?)</published>", e, re.S).group(1).strip()
    authors = re.findall(r"<name>(.*?)</name>", e, re.S)
    return {"title": title, "id": ident, "published": published[:4],
            "first_author": authors[0] if authors else "?", "n_authors": len(authors)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default=os.path.join(ROOT, "opportunities", "gemma4-paper", "refs_report.json"))
    args = ap.parse_args()

    rows, failures = [], 0
    for key, title in REFS:
        try:
            hit = parse(fetch(title))
        except Exception as exc:  # noqa: BLE001
            hit = None
            print(f"ERROR {key}: {type(exc).__name__}: {exc}")
        if hit is None:
            failures += 1
            rows.append({"key": key, "query": title, "found": False})
            print(f"NOT FOUND  {key:16s} {title}")
            continue
        # a sane match: most query tokens appear in the returned title
        toks = [t for t in re.findall(r"[a-z0-9]+", title.lower()) if len(t) > 3]
        got = hit["title"].lower()
        overlap = sum(1 for t in toks if t in got) / max(len(toks), 1)
        ok = overlap >= 0.6
        failures += 0 if ok else 1
        rows.append({"key": key, "query": title, "found": True, "match": ok,
                     "title": hit["title"], "first_author": hit["first_author"],
                     "year": hit["published"], "arxiv": hit["id"], "overlap": round(overlap, 2)})
        print(f"{'OK  ' if ok else 'WEAK'}  {key:16s} {hit['published']} {hit['first_author']:18s} "
              f"{hit['id'].rsplit('/', 1)[-1]:14s} overlap={overlap:.2f}")

    print(f"\n{len(rows) - failures}/{len(rows)} references matched")
    with open(args.json, "w", encoding="utf-8") as f:
        json.dump({"references": rows, "failures": failures}, f, indent=2)
    print(f"wrote {args.json}")
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())

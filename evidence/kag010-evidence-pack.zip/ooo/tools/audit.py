#!/usr/bin/env python3
"""OOO tamper-evident audit log (Constitution v1.1, Sections 0, 20, 21).

Usage (from workspace root):
  python ooo/tools/audit.py append EVENT [DETAIL]   append a hash-chained entry
  python ooo/tools/audit.py verify [--path FILE]    verify chain (exit 0 = OK, 1 = FAIL)
  python ooo/tools/audit.py seal FILE               record sha256 of a protected file
  python ooo/tools/audit.py check FILE              compare current sha256 to last seal

Chain design: each entry's hash = sha256(canonical JSON of the entry without
'hash'), and each entry embeds the previous entry's hash. Modification,
insertion, removal, or reordering of any entry breaks the chain.

Known limitation (documented in EXP-001): truncation of the log TAIL is not
detectable by the chain alone. Mitigation: the head hash is anchored outside
the log itself -- recorded in every checkpoint and report delivered to Robert.
"""
import argparse
import datetime
import getpass
import hashlib
import json
import os
import sys

DEFAULT_LOG = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "audit", "audit_log.jsonl"))


def canon(obj):
    return json.dumps(obj, sort_keys=True, ensure_ascii=False)


def sha(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read_entries(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def append(event, detail="", path=DEFAULT_LOG):
    entries = read_entries(path)
    prev = entries[-1]["hash"] if entries else "GENESIS"
    entry = {
        "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"),
        "actor": getpass.getuser(),
        "event": event,
        "detail": detail,
        "prev_hash": prev,
    }
    entry["hash"] = sha(canon(entry))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(canon(entry) + "\n")
    print(f"appended #{len(entries)} event={event} hash={entry['hash'][:16]}...")
    return entry


def verify(path):
    entries = read_entries(path)
    prev = "GENESIS"
    for i, e in enumerate(entries):
        claimed = e.get("hash")
        rest = {k: v for k, v in e.items() if k != "hash"}
        if claimed != sha(canon(rest)):
            print(f"FAIL entry {i}: hash mismatch (content modified)")
            return 1
        if e.get("prev_hash") != prev:
            print(f"FAIL entry {i}: prev_hash mismatch (insertion/removal/reorder)")
            return 1
        prev = claimed
    if entries:
        print(f"OK: {len(entries)} entries, chain intact, head={prev}")
    else:
        print("OK: empty log (0 entries)")
    return 0


def seal(path):
    target = os.path.abspath(path)
    h = sha_file(target)
    append("SEAL", f"file={target} sha256={h}")
    return h


def check(path):
    target = os.path.abspath(path)
    seals = [e for e in read_entries(DEFAULT_LOG)
             if e.get("event") == "SEAL" and f"file={target}" in e.get("detail", "")]
    if not seals:
        print(f"NO SEAL recorded for {target}")
        return 1
    expected = seals[-1]["detail"].split("sha256=")[1]
    actual = sha_file(target)
    if actual == expected:
        print(f"MATCH: {target} sha256={actual}")
        return 0
    print(f"CHANGED: {target}\n  sealed = {expected}\n  actual = {actual}")
    return 1


def main():
    ap = argparse.ArgumentParser(description="OOO tamper-evident audit log")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("append")
    a.add_argument("event")
    a.add_argument("detail", nargs="?", default="")
    v = sub.add_parser("verify")
    v.add_argument("--path", default=DEFAULT_LOG)
    s = sub.add_parser("seal")
    s.add_argument("file")
    c = sub.add_parser("check")
    c.add_argument("file")
    args = ap.parse_args()
    if args.cmd == "append":
        append(args.event, args.detail)
    elif args.cmd == "verify":
        sys.exit(verify(args.path))
    elif args.cmd == "seal":
        seal(args.file)
    elif args.cmd == "check":
        sys.exit(check(args.file))


if __name__ == "__main__":
    main()
